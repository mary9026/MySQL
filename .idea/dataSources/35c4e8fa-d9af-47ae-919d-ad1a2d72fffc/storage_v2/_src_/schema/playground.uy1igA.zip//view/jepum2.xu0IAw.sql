create definer = playground@`%` view 제품2 as
select `playground`.`sales_product2`.`prodno`   AS `prodno`,
       `playground`.`sales_product2`.`stock`    AS `stock`,
       `playground`.`sales_product2`.`prdmaker` AS `prdmaker`
from `playground`.`sales_product2`;

