create definer = playground@`%` view departments2 as
select `playground`.`departments`.`department_id`   AS `department_id`,
       `playground`.`departments`.`department_name` AS `department_name`,
       `playground`.`departments`.`manager_id`      AS `mgr_id`,
       `playground`.`departments`.`location_id`     AS `location_id`
from `playground`.`departments`;

