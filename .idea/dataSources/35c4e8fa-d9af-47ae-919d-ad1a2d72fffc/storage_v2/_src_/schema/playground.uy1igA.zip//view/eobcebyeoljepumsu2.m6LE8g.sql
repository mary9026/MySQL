create definer = playground@`%` view 업체별제품수2 as
select `playground`.`sales_products`.`prdmaker` AS `업체`, count(`playground`.`sales_products`.`prodno`) AS `제품수`
from `playground`.`sales_products`
group by `playground`.`sales_products`.`prdmaker`;

